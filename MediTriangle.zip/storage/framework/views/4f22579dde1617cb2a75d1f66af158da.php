<?php $__env->startSection('style'); ?>
    <style>
        .display {
            background-image: url(https://cdn.dribbble.com/userupload/4356547/file/original-291102d063a21bd3a3fdcd1ed2d8606a.gif);
            background-repeat: round;
            width: 100%;
            height: 50vh;
            background-repeat-y: no-repeat;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Appointment Start -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="row justify-content-md-center">
            <div class="col-lg-8">
                <div class="bg-light text-center rounded p-5">
                    <h1 class="mb-5">Successfully Done</h1>
                    <hr>
                    <div class="mb-3 text-center">
                        <ul id="progressbar" style="display: flex;justify-content: center;">
                            <li class="prog-bar active" id="account"><strong>Book</strong></li>
                            <li class="prog-bar active" id="confirm"><strong>Finish</strong></li>
                        </ul>
                    </div>
                    <div class="info mt-3">
                        <div class="display">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Appointment End -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.config.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel project\MediTriangle\resources\views/frontend/appoinment/personal.blade.php ENDPATH**/ ?>