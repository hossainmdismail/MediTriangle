<?php $__env->startSection('content'); ?>

    <!-- Search Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="text-center mx-auto mb-5" style="max-width: 500px;">
                <h5 class="d-inline-block text-primary text-uppercase border-bottom border-5">Find A Doctor</h5>
                <h1 class="display-4 mb-4">Find A Healthcare Professionals</h1>
                <h5 class="fw-normal">Duo ipsum erat stet dolor sea ut nonumy tempor. Tempor duo lorem eos sit sed ipsum takimata ipsum sit est. Ipsum ea voluptua ipsum sit justo</h5>
            </div>
            <form action="<?php echo e(route('doctor.find')); ?>" method="get">
            <?php echo csrf_field(); ?>
            <div class="mx-auto" style="width: 100%; max-width: 600px;">
                <div class="input-group">
                    <select class="form-select border-primary w-5" name="department" style="height: 60px;">
                        <option selected>Department</option>
                        <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($departments->id); ?>"><?php echo e($departments->department); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    
                    <button class="btn btn-dark border-0 w-25">Search</button>
                </div>
            </div>
            </form>
        </div>
    </div>
    <!-- Search End -->


    <!-- Search Result Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row g-5">
                <?php if($doctors != null): ?>
                  <?php $__currentLoopData = $doctors->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 team-item">
                        <div class="row g-0 bg-light rounded overflow-hidden">
                            <div class="col-12 col-sm-5 h-100">
                                <img class="img-fluid h-100" src="<?php echo e(asset('uploads/doctor/'.$doctor->profile)); ?>" style="object-fit: cover;">
                            </div>
                            <div class="col-12 col-sm-7 h-100 d-flex flex-column">
                                <div class="mt-auto p-4">
                                    <h3><?php echo e($doctor->name); ?></h3>
                                    <h6 class="fw-normal fst-italic text-primary mb-4"><?php echo e($doctor->con_department->department); ?></h6>
                                    <p class="mb-2" style="border-bottom: 1px solid #1ab8ae33;"><i class="fa-solid fa-house-medical text-primary p-2"></i><?php echo e($doctor->con_hospital->hospital); ?></p>
                                    <p class="mb-2" style="border-bottom: 1px solid #1ab8ae33;"><i class="fa-solid fa-stethoscope text-primary p-2"></i><?php echo e($doctor->career_title); ?></p>
                                    <p class="m-0"><i class="fa-solid fa-book text-primary p-2"></i><?php echo e($doctor->speciality); ?></p>
                                    <a class="btn btn-outline-dark btn-sm mt-3" href="<?php echo e(route('link.appoinment')); ?>">Appointment</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 text-center">
                    <?php echo e($doctors->links('pagination::bootstrap-4')); ?>

                </div>

                <?php endif; ?>



            </div>
        </div>
    </div>
    <!-- Search Result End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.config.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel project\MediTriangle\resources\views/frontend/doctor/index.blade.php ENDPATH**/ ?>