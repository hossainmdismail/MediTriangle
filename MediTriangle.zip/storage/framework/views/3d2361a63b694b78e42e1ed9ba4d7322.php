<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row my-5">
        <div class="col-md-3 mb-3">
            <div class="card">
                <div class="card-body">
                    <a href="<?php echo e(route('profile')); ?>" class="btn btn-primary w-100 my-2">Profile</a>
                    <a href="<?php echo e(route('profile.order')); ?>" class="btn btn-primary w-100 my-2">Order</a>
                    <form action="<?php echo e(route('logout')); ?>" method="post">
                    <button type="submit" class="btn btn-danger w-100 my-2"><?php echo csrf_field(); ?> LogOut</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-body">
                    <h5 class="mb-3" style="border-left: 6px solid #1ab8ae;padding-left: 9px">Profile</h5>
                    <form action="<?php echo e(route('profile.update')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <input style="background-color: #1ab8ae0f !important;" type="text" name="name" class="form-control py-3 border-0" value="<?php echo e($data->name); ?>">
                            </div>

                            <div class="col-md-6 mb-3">
                                <input style="background-color: #1ab8ae0f !important;" type="text" name="number" class="form-control py-3 border-0" value="<?php echo e($data->number); ?>" readonly>
                            </div>

                            <div class="col-12 mb-3">
                                <input style="background-color: #1ab8ae0f !important;" type="text" name="email" class="form-control py-3 border-0" value="<?php echo e($data->email); ?>" readonly>
                            </div>

                            <div class="col-12 mb-3">
                                <input style="background-color: #1ab8ae0f !important;" type="text" name="address" class="form-control py-3 border-0" value="<?php echo e($data->address); ?>" placeholder="Address">
                            </div>

                            <div class="col-12 mb-3 text-end">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </div>
                    </form>
                    <hr>
                    <h5 class="mb-3" style="border-left: 6px solid #1ab8ae;padding-left: 9px">Password</h5>
                    <form action="<?php echo e(route('profile.password.reset')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <input style="background-color: #1ab8ae0f !important;" type="password" name="old_password" class="form-control py-3 border-0 <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Old Password">
                                </div>

                                <div class="col-12 mb-3">
                                    <input style="background-color: #1ab8ae0f !important;" type="password" name="new_password" class="form-control py-3 border-0 <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="New Password">
                                </div>

                                <div class="col-12 mb-3">
                                    <input style="background-color: #1ab8ae0f !important;" type="password" name="con_password" class="form-control py-3 border-0 <?php $__errorArgs = ['con_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Confirm Password">
                                </div>

                                <div class="col-12 mb-3">
                                    
                                </div>

                                <div class="col-12 mb-3 text-end">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </div>
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.config.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel project\MediTriangle\resources\views/frontend/profile/index.blade.php ENDPATH**/ ?>