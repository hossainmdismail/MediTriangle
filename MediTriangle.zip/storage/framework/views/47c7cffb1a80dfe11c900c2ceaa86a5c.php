<div class="d-grid">
    <button type="<?php echo e($type); ?>" class="btn btn-primary"><?php echo e($add); ?></button>
</div>
<?php /**PATH E:\Laravel project\MediTriangle\resources\views/components/button.blade.php ENDPATH**/ ?>