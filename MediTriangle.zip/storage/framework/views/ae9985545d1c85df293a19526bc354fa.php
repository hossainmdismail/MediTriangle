
<?php /**PATH E:\Laravel project\MediTriangle\resources\views/frontend/auth/reset.blade.php ENDPATH**/ ?>