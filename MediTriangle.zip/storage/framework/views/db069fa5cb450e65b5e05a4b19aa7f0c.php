<div class="mb-3">
    <label class="form-label"><?php echo e($label); ?></label>
    <input name="<?php echo e($name); ?>" id="name" type="<?php echo e($type); ?>" class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo e($placeholder); ?>">
</div>
<?php /**PATH E:\Laravel project\MediTriangle\resources\views/components/input.blade.php ENDPATH**/ ?>