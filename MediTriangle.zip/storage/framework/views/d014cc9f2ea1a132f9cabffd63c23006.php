<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="layout-specing">
        <div class="row mb-3">
            <div class="d-md-flex justify-content-between">
                <h5 class="mb-0">Owner</h5>

                <nav aria-label="breadcrumb" class="d-inline-block mt-4 mt-sm-0">
                    <ul class="breadcrumb bg-transparent rounded mb-0 p-0">
                        <li class="breadcrumb-item"><a href="#">Website Info</a></li><i style="font-size:12px;padding-left:6px" class="fa-solid fa-chevron-right"></i>
                        
                    </ul>
                </nav>
            </div>
        </div><!--end row-->

        <div class="row">
            
            <div class="col-md-5 mb-3">
                <div class="card border-0 p-4 rounded shadow">
                    <form action="<?php echo e(route('owner.store')); ?>" method="POST" class="mt-4">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <?php if (isset($component)) { $__componentOriginal786b6632e4e03cdf0a10e8880993f28a = $component; } ?>
<?php $component = App\View\Components\Input::resolve(['type' => 'text','label' => 'Brand Name','name' => 'name','placeholder' => 'Name'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal786b6632e4e03cdf0a10e8880993f28a)): ?>
<?php $component = $__componentOriginal786b6632e4e03cdf0a10e8880993f28a; ?>
<?php unset($__componentOriginal786b6632e4e03cdf0a10e8880993f28a); ?>
<?php endif; ?>
                            </div>

                            <div class="col-md-6">
                                <?php if (isset($component)) { $__componentOriginal786b6632e4e03cdf0a10e8880993f28a = $component; } ?>
<?php $component = App\View\Components\Input::resolve(['type' => 'email','label' => 'Brand Email','name' => 'email','placeholder' => 'example@mail.com'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal786b6632e4e03cdf0a10e8880993f28a)): ?>
<?php $component = $__componentOriginal786b6632e4e03cdf0a10e8880993f28a; ?>
<?php unset($__componentOriginal786b6632e4e03cdf0a10e8880993f28a); ?>
<?php endif; ?>
                            </div>

                            <div class="col-md-6">
                                <?php if (isset($component)) { $__componentOriginal5eeada6d1cd8abcd76ed3a224241e1c2 = $component; } ?>
<?php $component = App\View\Components\InputIcon::resolve(['type' => 'number','label' => 'Number','name' => 'number','placeholder' => '00-000-00','icon' => +880] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Input-Icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputIcon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5eeada6d1cd8abcd76ed3a224241e1c2)): ?>
<?php $component = $__componentOriginal5eeada6d1cd8abcd76ed3a224241e1c2; ?>
<?php unset($__componentOriginal5eeada6d1cd8abcd76ed3a224241e1c2); ?>
<?php endif; ?>
                            </div>

                            <div class="col-md-6">
                                <?php if (isset($component)) { $__componentOriginal5eeada6d1cd8abcd76ed3a224241e1c2 = $component; } ?>
<?php $component = App\View\Components\InputIcon::resolve(['type' => 'number','label' => 'Landline','name' => 'landline','placeholder' => '000-0000-000','icon' => +880] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Input-Icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputIcon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5eeada6d1cd8abcd76ed3a224241e1c2)): ?>
<?php $component = $__componentOriginal5eeada6d1cd8abcd76ed3a224241e1c2; ?>
<?php unset($__componentOriginal5eeada6d1cd8abcd76ed3a224241e1c2); ?>
<?php endif; ?>
                            </div>

                            <div class="col-12">
                                <?php if (isset($component)) { $__componentOriginal786b6632e4e03cdf0a10e8880993f28a = $component; } ?>
<?php $component = App\View\Components\Input::resolve(['type' => 'text','label' => 'Address','name' => 'address','placeholder' => 'Street Address'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal786b6632e4e03cdf0a10e8880993f28a)): ?>
<?php $component = $__componentOriginal786b6632e4e03cdf0a10e8880993f28a; ?>
<?php unset($__componentOriginal786b6632e4e03cdf0a10e8880993f28a); ?>
<?php endif; ?>
                            </div>
                        <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>

            
            <div class="col-md-7">
                <div class="table-responsive shadow rounded">
                    <?php if($datas->count() != 0 ): ?>
                        <table class="table table-center bg-white mb-0">
                            <thead>
                                <tr>
                                    <th class="border-bottom p-3" style="min-width: 50px;">Id</th>
                                    <th class="border-bottom p-3" style="min-width: 180px;">Information</th>
                                    <th class="border-bottom p-3">Status</th>
                                    <th class="border-bottom p-3 text-center" style="min-width: 100px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="p-3"><?php echo e($key+1); ?></th>
                                    <td class="p-3">
                                        <?php echo e($data->name == null?'null': $data->name); ?> <br> <hr class="m-0">
                                        <?php echo e($data->email == null?'null': $data->email); ?> <br> <hr class="m-0">
                                        <?php echo e($data->number == null?'null': $data->number); ?> <br><hr class="m-0">
                                        <?php echo e($data->landline == null?'null': $data->landline); ?> <br><hr class="m-0">
                                        <?php echo e($data->address == null?'null': $data->address); ?>

                                    </td>
                                    <td class="p-3"><span class="badge bg-soft-<?php echo e($data->status == 0?'danger':'success'); ?>"><?php echo e($data->status == 0 ?'Deactive':'active'); ?></span></td>
                                    <td class="text-end p-3">
                                        
                                        <a href="<?php echo e(route('owner.edit',$data->id)); ?>" class="btn btn-icon btn-pills btn-soft-success"><i class="fa-solid fa-pen-to-square"></i></a>

                                        

                                        <a href="<?php echo e(route('owner.delete',$data->id)); ?>" data-bs-toggle="modal" data-bs-target="#LoginForm"  class="delete_value btn btn-icon btn-pills btn-soft-danger"><i class="fa-solid fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                    <span class="text-center bg-soft-warning"><p class="m-0">No Data Found !</p></span>
                    <?php endif; ?>

                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $(".btn").click(function(){
                var val = $(this).attr('href');
                $('#delete_confirm').attr('href', val);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.config.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel project\MediTriangle\resources\views/backend/owner/index.blade.php ENDPATH**/ ?>