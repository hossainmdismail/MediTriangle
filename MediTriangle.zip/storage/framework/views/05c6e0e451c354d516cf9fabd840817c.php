<?php $__env->startSection('content'); ?>
<!-- Appointment Start -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="row justify-content-md-center">
            <div class="col-lg-8">
                <div class="bg-light text-center rounded p-5">
                    <h1 class="mb-5">Visa Invitation</h1>
                    <hr>
                    <div class="mb-3">
                        <ul id="progressbar">
                            <li class="prog-bar active" id="account"><strong>Account</strong></li>
                            <li id="personal"><strong>Personal</strong></li>
                            <li id="payment"><strong>Payment</strong></li>
                            <li id="confirm"><strong>Finish</strong></li>
                        </ul>
                    </div>
                    <form action="<?php echo e(route('store.appoinment')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-12 col-sm-6">
                                <select class="form-select bg-white border-0 country <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="country_id" style="height: 55px;">
                                    <option value="" selected>Choose Country</option>
                                    <?php $__currentLoopData = App\Models\CountryModel::where('status', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->country); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            
                            <div class="col-12 col-sm-6">
                                <select class="form-select bg-white border-0 state <?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="state" name="state_id" style="height: 55px;">
                                    <option value="<?php echo e(old('state_id')); ?>" selected><?php echo e(old('state_id')); ?>---</option>
                                </select>
                            </div>
                            
                            <div class="col-12 col-sm-6">
                                <select class="form-select bg-white border-0 hospital <?php $__errorArgs = ['hospital_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="hospital" name="hospital_id" style="height: 55px;">
                                    <option value="" selected>---</option>
                                </select>
                            </div>
                            
                            <div class="col-12 col-sm-6">
                                <select class="form-select bg-white border-0 department <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="departmentVal" name="hospital_id" style="height: 55px;">
                                    <option value="" selected>---</option>
                                </select>
                            </div>
                            
                            <div class="col-12">
                                <select class="form-select bg-white border-0 <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="doctors" name="doctor_id" style="height: 55px;">
                                    <option value="" selected>---</option>
                                </select>
                            </div>
                            
                            <div class="col-12">
                                <textarea type="text" name="note" class="form-control bg-white border-0" placeholder="Note.." rows="5"></textarea>
                            </div>
                            
                            

                            <div class="col-12">
                                <button class="btn btn-primary w-100 py-3" type="submit">Apply</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Appointment End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    var countryVal = '';
    console.log(countryVal);
</script>



<script>
    //Get State
    $('.country').change(function(){
        var country = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type:'POST',
            url:'<?php echo e(route('ajax.state')); ?>',
            data:{'country_id':country},
            success:function(data) {
                $('#state').html(data);
                countryVal = data;
            }
        })
    });

    $('.state').change(function(){
        var state = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type:'POST',
            url:'<?php echo e(route('ajax.department')); ?>',
            data:{'state_id':state},
            success:function(data) {
                $('#hospital').html(data);
            }
        })
    });

    $('.hospital').change(function(){
        var hospital = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type:'POST',
            url:'<?php echo e(route('ajax.hospital')); ?>',
            data:{'hospital_id':hospital},
            success:function(data) {
                $('#departmentVal').html(data);
            }
        })
    });

    $('.department').change(function(){
        var department = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type:'POST',
            url:'<?php echo e(route('ajax.doctor')); ?>',
            data:{'department_id':department},
            success:function(data) {
                $('#doctors').html(data);
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.config.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel project\MediTriangle\resources\views/frontend/visa/index.blade.php ENDPATH**/ ?>