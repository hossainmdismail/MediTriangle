<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row my-5">

        <div class="col-md-6 m-auto my-5 ">
            <div class="card my-5">
                <div class="card-body">
                    <h5 class="mb-3" style="border-left: 6px solid #1ab8ae;padding-left: 9px">Match The Code</h5>
                    <form action="<?php echo e(route('profile.forget.pass.verify.confirme')); ?>" method="post">
                    <?php echo csrf_field(); ?>


                    <div class="mb-3">
                        <input style="background-color: #1ab8ae0f !important;" type="text" name="code" class="form-control py-3 border-1 <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Code">
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($data); ?>">

                    <div class=" text-end">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php if(session()->get('data')): ?>
    <script>
        const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
        })

        Toast.fire({
        icon: 'success',
        title: 'Code Sent via SMS'
        })
    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.config.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel project\MediTriangle\resources\views/frontend/auth/verify.blade.php ENDPATH**/ ?>