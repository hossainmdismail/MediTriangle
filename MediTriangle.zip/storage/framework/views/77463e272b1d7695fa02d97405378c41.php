<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row my-5">
        <div class="col-md-3 mb-3">
            <div class="card">
                <div class="card-body">
                    <a href="<?php echo e(route('profile')); ?>" class="btn btn-primary w-100 my-2">Profile</a>
                    <a href="<?php echo e(route('profile.order')); ?>" class="btn btn-primary w-100 my-2">Order</a>
                    <form action="<?php echo e(route('logout')); ?>" method="post">
                    <button type="submit" class="btn btn-danger w-100 my-2"><?php echo csrf_field(); ?> LogOut</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            
            <h5 class="mb-3" style="border-left: 6px solid #1ab8ae;padding-left: 9px">Appointment</h5>
            <div class="card mb-5">
                <div class="card-body" style="overflow-x: scroll;scroll-behavior: auto;">
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">ID</th>
                            
                            <th scope="col">Doctor</th>
                            <th scope="col">Appointment</th>
                            <th scope="col">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php if($orders->count() != 0): ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td><?php echo e($order->order_id); ?>

                                    <?php if($order->appointment_type == 1): ?>
                                    <span class="badge bg-secondary">Appointment</span>
                                    <?php elseif($order->appointment_type == 2): ?>
                                    <span class="badge bg-secondary">Video</span>
                                    <?php elseif($order->appointment_type == 3): ?>
                                    <span class="badge bg-primary">Visa</span>
                                    <?php endif; ?></td>
                                    
                                    <td><img src="<?php echo e(asset('uploads/doctor/'.$order->con_doctor->profile)); ?>" style="width: 20px;border-radius: 6px;margin-right: 7px;" alt=""><?php echo e($order->con_doctor->name); ?></td>
                                    <td><span class="badge bg-<?php echo e($order->activity == null?'info':'primary'); ?>"><?php echo e($order->activity == null?'Waiting':$order->activity->format('M-d-Y')); ?></span></td>
                                    <td>
                                        <?php if($order->status == 0): ?>
                                        <span class="badge bg-info">Proccessing</span>
                                        <?php elseif($order->status == 1): ?>
                                        <span class="badge bg-primary">Confirm</span>
                                        <?php elseif($order->status == 2): ?>
                                        <span class="badge bg-danger">Cancel</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo e($orders->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
            
            <?php if($medicines->count() != 0): ?>
            <h5 class="mb-3" style="border-left: 6px solid #1ab8ae;padding-left: 9px">Shop</h5>
            <div class="card mb-3">
                <div class="card-body" style="overflow-x: scroll;scroll-behavior: auto;">
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">ID</th>
                            
                            <th scope="col">Medicine</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td><?php echo e($medicine->order_id); ?>

                                    
                                    </td>
                                    
                                    <td>
                                        <?php $__currentLoopData = App\Models\MedicineOrder::where('order_id',$medicine->order_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($medi->medicine); ?> <br></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = App\Models\MedicineOrder::where('order_id',$medicine->order_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($medi->quantity); ?> <br></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php if($medicine->status == 0): ?>
                                        <span class="badge bg-info">Proccessing</span>
                                        <?php elseif($medicine->status == 1): ?>
                                        <span class="badge bg-primary">Confirm</span>
                                        <?php elseif($medicine->status == 2): ?>
                                        <span class="badge bg-danger">Cancel</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($orders->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.config.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel project\MediTriangle\resources\views/frontend/profile/order.blade.php ENDPATH**/ ?>