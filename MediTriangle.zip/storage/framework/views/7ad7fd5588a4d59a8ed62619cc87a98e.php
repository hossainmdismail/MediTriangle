<div class="mb-3">
    <label class="form-label"><?php echo e($label); ?></label>
    <div class="input-group flex-nowrap">
        <span class="input-group-text bg-light border border-end-0 text-dark" id="insta-id"><?php echo e($icon); ?></span>
        <input name="<?php echo e($name); ?>" id="name" type="<?php echo e($type); ?>" class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo e($placeholder); ?>" aria-label="Username" aria-describedby="insta-id">
    </div>
</div>
<?php /**PATH E:\Laravel project\MediTriangle\resources\views/components/input-icon.blade.php ENDPATH**/ ?>