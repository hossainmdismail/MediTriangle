<?php $__env->startSection('content'); ?>

<div class="modal fade" id="LoginFormTwo" tabindex="-1" aria-labelledby="LoginForm-title" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-header border-bottom">
                <h5 class="modal-title" id="LoginForm-title">Are You Sure?</h5>
                <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="modal-body">
                <div class="p-3 rounded box-shadow">
                    <p class="text-danger mb-0">This process cannot be undone ! <br> Do you really want to delete those records?</p>
                </div>
            </div>
            <div class="modal-footer">
                
                <a href="" id="delete_confirmTwo" class="btn btn-danger">Delete</a>
            </div>
        </div>
    </div>
</div>


<div class="container-fluid">

    <div class="layout-specing">
        <div class="row mb-3">
            <div class="d-md-flex justify-content-between">
                <h5 class="mb-0">Doctors</h5>

                <nav aria-label="breadcrumb" class="d-inline-block mt-4 mt-sm-0">
                    <ul class="breadcrumb bg-transparent rounded mb-0 p-0">
                        <li class="breadcrumb-item">Manage</li><i style="font-size:12px;padding-left:6px" class="fa-solid fa-chevron-right"></i>
                        
                    </ul>
                </nav>
            </div>
        </div><!--end row-->


        <div class="row">
            
            <div class="col-md-12">
                <div class="table-responsive shadow rounded">
                    <?php if($datas->count() != 0 ): ?>
                    <table class="table table-center bg-white mb-0">
                        <thead>
                            <tr>
                                <th class="border-bottom p-3" >Doctor</th>
                                <th class="border-bottom p-3" >Information</th>
                                <th class="border-bottom p-3" >Database</th>
                                <th class="border-bottom p-3">Status</th>
                                <th class="border-bottom p-3">Created</th>
                                <th class="border-bottom p-3 text-end" style="min-width: 100px;">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="p-3"><img style="width:40px" src="<?php echo e(asset('uploads/doctor/'.$data->profile)); ?>" alt="">
                                    </td>

                                    <td class="p-3">
                                        <p class="mb-0"><span class="badge bg-secondary "><?php echo e($data->name); ?></span></p>
                                        <hr style="margin:0.2rem 0">
                                        <p class="mb-0"><?php echo e($data->career_title); ?></p>
                                        <hr style="margin:0.2rem 0">
                                        <p class="mb-0"><?php echo e($data->speciality); ?></p>
                                    </td>

                                    <td class="p-3">
                                        <p class="mb-0"><?php echo e($data->con_country == null ?'Unknown':$data->con_country->country); ?></p>
                                        <hr style="margin:0.2rem 0">
                                        <p class="mb-0"><?php echo e($data->con_state == null ?'Unknown':$data->con_state->state); ?></p>
                                        <hr style="margin:0.2rem 0">
                                        <p class="mb-0"><?php echo e($data->con_hospital == null ?'Unknown':$data->con_hospital->hospital); ?></p>
                                        <hr style="margin:0.2rem 0">

                                        <p class="mb-0"><span class="badge bg-secondary "><?php echo e($data->con_department == null ?'Unknown':$data->con_department->department); ?></span></p>
                                    </td>

                                    <td class="p-3"><span class="badge bg-soft-<?php echo e($data->status == 0?'danger':'success'); ?>"><?php echo e($data->status == 0 ?'Deactive':'active'); ?></span></td>

                                    <td class="p-3"><span class="badge bg-soft-success"><?php echo e($data->created_at->diffForHumans()); ?></span></td>
                                    <td class="text-end p-3">
                                        <a href="<?php echo e(route('doctor.edit',$data->id)); ?>" class="update_value btn btn-icon btn-pills btn-soft-success"><i class="fa-solid fa-pen-to-square"></i></a>
                                        <a href="<?php echo e(route('doctor.delete',$data->id)); ?>" data-bs-toggle="modal" data-bs-target="#LoginFormTwo" class="delete_value btn btn-icon btn-pills btn-soft-danger"><i class="fa-solid fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                    <span class="text-center bg-soft-warning"><p class="m-0">No Data Found !</p></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="mt-3 d-flex justify-content-between">
                <?php echo e($datas->links('pagination::bootstrap-4')); ?>

                <div class="button">
                    <a href="<?php echo e(route('doctor.link')); ?>" class="btn btn-info btn-sm">Add Doctor</a>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(".delete_value").click(function(){
            var val = $(this).attr('href');
            $('#delete_confirmTwo').attr('href', val);
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.config.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel project\MediTriangle\resources\views/backend/doctor/manage.blade.php ENDPATH**/ ?>