<?php $__env->startSection('style'); ?>
<style>
    #billings{
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-5 my-5">
    <div class="container">
        <div class="row gx-5">
            <div class="col-lg-5 mb-5 mb-lg-0">
                <div class="mb-4">
                    <h5 class="d-inline-block text-primary text-uppercase border-bottom border-5">Medicines</h5>
                    <h1 class="display-4">Buy Best Medicine For Your Family</h1>
                </div>
                <p class="mb-5">Eirmod sed tempor lorem ut dolores. Aliquyam sit sadipscing kasd ipsum. Dolor ea et dolore et at sea ea at dolor, justo ipsum duo rebum sea invidunt voluptua. Eos vero eos vero ea et dolore eirmod et. Dolores diam duo invidunt lorem. Elitr ut dolores magna sit. Sea dolore sanctus sed et. Takimata takimata sanctus sed.</p>
                
            </div>
            <div class="col-lg-7">
                <div class="bg-light text-center rounded p-4">
                    <h1 class="mb-4">Order Medicine</h1>
                    <form class="medi" action="<?php echo e(route('store.medicine')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3 mb-3 medi">
                            <div class="col-12 col-sm-8">
                                <input type="text" name="medicine[]" class="form-control bg-white border-0 inp <?php if(session('validate')): ?> is-invalid <?php endif; ?>" placeholder="Medicine" style="height: 55px;">
                            </div>
                            <div class="col-12 col-sm-3">
                                <input type="number" name="quantity[]" class="form-control bg-white border-0 <?php if(session('validate')): ?> is-invalid <?php endif; ?>" placeholder="Quantity" style="height: 55px;">
                            </div>
                            <div class="col-12 col-sm-1">
                                <button type="button" class="btn btn-primary mt-2" id="plus">+</button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 mb-3 text-start">
                                <label for="report" class="form-label">Reports</label>
                                <input type="file" name="report" class="form-control bg-white border-0">
                            </div>
                        </div>
                        <div id="billings" class="row">
                            <hr>
                            <h5 class="text-start" style="border-left: 6px solid #1ab8ae;margin-left: 15px;">Billing Address</h5>
                            <div class="col-12 mb-3">
                                <input type="text" name="address" class="form-control bg-white border-0 <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Address" value="<?php echo e(old('address')); ?>" style="height: 55px;">
                            </div>
                            <div class="col-12 mb-3">
                                <input type="text" name="name" class="form-control bg-white border-0 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Name" value="<?php echo e(old('name')); ?>" style="height: 55px;">
                            </div>
                            <div class="col-12 mb-3">
                                <input type="number" name="mobile" class="form-control bg-white border-0 <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Number" value="<?php echo e(old('number')); ?>" style="height: 55px;">
                            </div>
                        </div>
                        <?php if(!Auth::user()): ?>
                                <div id="userinfo" class="mt-5">

                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item" role="presentation">
                                        <button name="submit" value="0" class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Registration</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                        <button name="submit" value="1" class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Login</button>
                                        </li>
                                    </ul>

                                    <div class="tab-content" id="myTabContent">
                                        
                                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

                                            <div class="row mt-3">
                                                <div class="col-12 mb-3">
                                                    <input type="text" name="number" class="form-control bg-white border-0 <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('number')); ?>" placeholder="01XXXXXXXXX">

                                                </div>
                                                <div class="col-12 mb-3">
                                                    <input type="text" name="email" class="form-control bg-white border-0" value="<?php echo e(old('email')); ?>" placeholder="Email">
                                                </div>
                                            </div>
                                        </div>


                                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                            <div class="row mt-3 justify-content center">
                                                <div class="col-6">
                                                    <p><a href="<?php echo e(route('login')); ?>">Click here</a> If you already have an account!</p>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <?php else: ?>

                                <?php endif; ?>
                        <div class="row">
                            <div class="col-12">
                                <button class="btn btn-primary w-100 py-3" type="submit">Make An Appointment</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $('.inp').click(function () {
            $('#billings').css('display','block');
        });
        $('#plus').click(function () {
            let inputNew = $('.medi:last').clone(true);
            $(inputNew).insertAfter('.medi:last');
        });
    </script>
    <?php if(session()->get('errors')): ?>
    <script>
        $('#billings').css('display','block');
    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.config.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel project\MediTriangle\resources\views/frontend/medicine/index.blade.php ENDPATH**/ ?>