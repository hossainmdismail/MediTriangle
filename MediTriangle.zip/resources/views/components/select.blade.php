<div class="mb-3">
    <label class="form-label">Country <span class="text-danger">*</span></label>
    <select class="form-select form-control" name="country_id">
        <option >-- Select Country--</option>
    </select>
</div>
