<div class="d-grid">
    <button type="{{ $type }}" class="btn btn-primary">{{ $add }}</button>
</div>
